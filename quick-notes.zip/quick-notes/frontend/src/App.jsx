import { useState, useEffect, useRef } from "react";
import "./index.css";

const API = "http://localhost:8000";

function formatDate(iso) {
  const d = new Date(iso + "Z");
  return d.toLocaleString(undefined, {
    month: "short", day: "numeric", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

export default function App() {
  const [notes, setNotes] = useState([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [editId, setEditId] = useState(null);
  const [freshId, setFreshId] = useState(null);
  const [status, setStatus] = useState(null); // { type: "success"|"error", msg }
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const titleRef = useRef(null);

  useEffect(() => { fetchNotes(); }, []);

  async function fetchNotes() {
    try {
      const res = await fetch(`${API}/notes`);
      const data = await res.json();
      setNotes(data);
    } catch {
      showStatus("error", "Could not reach the server.");
    }
  }

  function showStatus(type, msg) {
    setStatus({ type, msg });
    setTimeout(() => setStatus(null), 3000);
  }

  async function handleSave() {
    if (!title.trim() || !content.trim()) {
      showStatus("error", "Title and content are required.");
      return;
    }
    setLoading(true);
    try {
      let res, saved;
      if (editId) {
        res = await fetch(`${API}/notes/${editId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title, content }),
        });
        saved = await res.json();
        setNotes(n => n.map(x => x.id === editId ? saved : x));
        showStatus("success", "Note updated.");
      } else {
        res = await fetch(`${API}/notes`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title, content }),
        });
        saved = await res.json();
        setNotes(n => [saved, ...n]);
        showStatus("success", "Note saved.");
      }
      setFreshId(saved.id);
      setTimeout(() => setFreshId(null), 1200);
      resetForm();
    } catch {
      showStatus("error", "Save failed. Is the backend running?");
    }
    setLoading(false);
  }

  async function handleDelete(id) {
    if (!confirm("Delete this note?")) return;
    await fetch(`${API}/notes/${id}`, { method: "DELETE" });
    setNotes(n => n.filter(x => x.id !== id));
    if (editId === id) resetForm();
    showStatus("success", "Note deleted.");
  }

  function startEdit(note) {
    setEditId(note.id);
    setTitle(note.title);
    setContent(note.content);
    titleRef.current?.focus();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function resetForm() {
    setTitle(""); setContent(""); setEditId(null);
  }

  const filtered = notes.filter(n =>
    n.title.toLowerCase().includes(search.toLowerCase()) ||
    n.content.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-inner">
          <div className="brand">
            <span className="brand-icon">◈</span>
            <span className="brand-name">QuickNotes</span>
          </div>
          <span className="note-count">{notes.length} note{notes.length !== 1 ? "s" : ""}</span>
        </div>
      </header>

      <main className="main">
        {/* Editor */}
        <section className="editor-section">
          <div className="editor-label">{editId ? "✎ Editing note" : "✦ New note"}</div>
          <input
            ref={titleRef}
            className="title-input"
            placeholder="Note title…"
            value={title}
            onChange={e => setTitle(e.target.value)}
            onKeyDown={e => e.key === "Enter" && document.getElementById("content-area").focus()}
          />
          <textarea
            id="content-area"
            className="content-input"
            placeholder="Write your note here…"
            value={content}
            onChange={e => setContent(e.target.value)}
            rows={6}
          />
          <div className="editor-actions">
            {editId && (
              <button className="btn btn-ghost" onClick={resetForm}>
                Cancel
              </button>
            )}
            <button
              className={`btn btn-primary ${loading ? "loading" : ""}`}
              onClick={handleSave}
              disabled={loading}
            >
              {loading ? "Saving…" : editId ? "Update Note" : "Save Note"}
            </button>
          </div>

          {status && (
            <div className={`toast toast-${status.type}`}>{status.msg}</div>
          )}
        </section>

        {/* Notes List */}
        <section className="notes-section">
          <div className="notes-header">
            <h2 className="notes-title">Your Notes</h2>
            <input
              className="search-input"
              placeholder="Search notes…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>

          {filtered.length === 0 ? (
            <div className="empty">
              {notes.length === 0
                ? "No notes yet — write your first one above."
                : "No notes match your search."}
            </div>
          ) : (
            <div className="notes-grid">
              {filtered.map(note => (
                <div
                  key={note.id}
                  className={`note-card ${freshId === note.id ? "note-fresh" : ""} ${editId === note.id ? "note-editing" : ""}`}
                >
                  <div className="note-body">
                    <div className="note-title">{note.title}</div>
                    <div className="note-content">{note.content}</div>
                  </div>
                  <div className="note-footer">
                    <span className="note-date">{formatDate(note.updated_at)}</span>
                    <div className="note-actions">
                      <button className="icon-btn" title="Edit" onClick={() => startEdit(note)}>✎</button>
                      <button className="icon-btn icon-btn-danger" title="Delete" onClick={() => handleDelete(note.id)}>✕</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
