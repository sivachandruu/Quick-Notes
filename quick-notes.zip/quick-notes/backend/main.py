from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime
import sqlite3
import os

app = FastAPI(title="Quick Notes API")

# Allow frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_PATH = "notes.db"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS notes (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            title    TEXT NOT NULL,
            content  TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


init_db()


# ---------- Schemas ----------

class NoteCreate(BaseModel):
    title: str
    content: str


class NoteUpdate(BaseModel):
    title: str | None = None
    content: str | None = None


class Note(BaseModel):
    id: int
    title: str
    content: str
    created_at: str
    updated_at: str


# ---------- Routes ----------

@app.get("/notes", response_model=list[Note])
def list_notes():
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM notes ORDER BY updated_at DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/notes", response_model=Note, status_code=201)
def create_note(note: NoteCreate):
    now = datetime.utcnow().isoformat()
    conn = get_db()
    cur = conn.execute(
        "INSERT INTO notes (title, content, created_at, updated_at) VALUES (?, ?, ?, ?)",
        (note.title.strip(), note.content.strip(), now, now),
    )
    conn.commit()
    row = conn.execute(
        "SELECT * FROM notes WHERE id = ?", (cur.lastrowid,)
    ).fetchone()
    conn.close()
    return dict(row)


@app.put("/notes/{note_id}", response_model=Note)
def update_note(note_id: int, note: NoteUpdate):
    now = datetime.utcnow().isoformat()
    conn = get_db()
    existing = conn.execute(
        "SELECT * FROM notes WHERE id = ?", (note_id,)
    ).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(status_code=404, detail="Note not found")

    title = note.title.strip() if note.title is not None else existing["title"]
    content = note.content.strip() if note.content is not None else existing["content"]

    conn.execute(
        "UPDATE notes SET title=?, content=?, updated_at=? WHERE id=?",
        (title, content, now, note_id),
    )
    conn.commit()
    row = conn.execute(
        "SELECT * FROM notes WHERE id = ?", (note_id,)
    ).fetchone()
    conn.close()
    return dict(row)


@app.delete("/notes/{note_id}", status_code=204)
def delete_note(note_id: int):
    conn = get_db()
    existing = conn.execute(
        "SELECT id FROM notes WHERE id = ?", (note_id,)
    ).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(status_code=404, detail="Note not found")
    conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
    conn.commit()
    conn.close()


@app.get("/health")
def health():
    return {"status": "ok"}
